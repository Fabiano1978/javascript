/*var media = 4;
if(media>=7){
    console.log("aprovado");
} else {
    console.log("Reprovado");
} */


/*var media = 4;
var faltas =1;
if(media>=7){
    console.log("aprovado");
}else if(media>=5 && faltas<2){
    console.log("recuperacao");
} else {
    console.log("reprovado");
} */

/*for (let numero = 1; numero <= 10; numero ++){
    console.log(numero);
} */

/*let x = 3;
const y = x++;
console.log(`x:${x}, y:${y}`); */

const listadepecas= ['pecas de teste', 'AB', 'peca B']
console.log('quantidade de caracteres')

if (listadepecas.length <=10) {

}

console.log('as pecas podem ser cadastradas');

for (let index =0; index < listadepecas.length; index++) {
    const pecaatual = listadepecas[index];
    if(pecaatual.length<3) {
        console.log(pecaatual + 'a peça possui nome inferior a 3 caracteres e não pode se cadastrada')} else {
            console.log(pecaatual + ':a peça pode ser cadastrada')
        } console.log('peso da peca')

        const pesodapecaemgramas = 50;
        if (pesodapecaemgramas >=100) {
            console.log("peso suficiente") } else {
                console.log("valor insuficiente")
            }

        }
    